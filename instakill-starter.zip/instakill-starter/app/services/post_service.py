
"""Application service for preparing posts."""

from app.domain.models import Post, User

def prepare_post(author: User, content: str) -> Post:
    """Prepare a Post from an existing user and post content.

    Raises:
        ValueError: If the user has no persisted ID or content is blank.
    """
    if author.id is None:
        raise ValueError("The author must have an existing user ID.")

    if not content.strip():
        raise ValueError("Post content cannot be empty.")

    return Post(
        user_id=author.id,
        content=content.strip(),
    )
