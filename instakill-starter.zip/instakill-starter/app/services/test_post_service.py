
import pytest

from app.domain.models import User
from app.services.post_service import prepare_post


def test_prepare_post_success():
    author = User(id=1, username="catalin")

    post = prepare_post(author, "My first post")

    assert post.user_id == 1
    assert post.content == "My first post"
    assert post.id is None


def test_prepare_post_rejects_blank_content():
    author = User(id=1, username="catalin")

    with pytest.raises(ValueError):
        prepare_post(author, "   ")


def test_prepare_post_rejects_user_without_id():
    author = User(username="catalin")

    with pytest.raises(ValueError):
        prepare_post(author, "Hello!")
