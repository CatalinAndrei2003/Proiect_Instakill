# API Contract: Create a Post

## 1. Endpoint

- **Method:** `POST`
- **Path:** `/posts`
- **Purpose:** Create a new post for an existing user.
- **Status:** Planned — documentation only. This endpoint is not implemented yet.

## 2. Request

Content-Type: `application/json`

Example request body:

```json
{
  "user_id": 1,
  "content": "Hello, InstaKill!"
}
```

### Request fields

| Field | Type | Requirements |
|---|---|---|
| `user_id` | Integer | Required; must identify an existing user. |
| `content` | String | Required; must not be empty or contain only whitespace. |

## 3. Successful response

HTTP status: `201 Created`

Example response body:

```json
{
  "id": 42,
  "user_id": 1,
  "content": "Hello, InstaKill!",
  "created_at": "2026-10-19T12:30:00"
}
```

The server assigns the post ID and creation timestamp. The response represents the newly created post.

## 4. Validation and error cases

### `422 Unprocessable Entity`

Returned when the request body is missing required fields, contains values of invalid types, or provides empty/whitespace-only content.

Example:

```json
{
  "detail": "Post content cannot be empty."
}
```

The exact error response format may follow FastAPI's standard validation response.

### `404 Not Found`

Returned when `user_id` does not identify an existing user.

Example:

```json
{
  "detail": "User not found."
}
```

## 5. Application boundary

The future HTTP endpoint will validate the request, resolve the author, and coordinate the application service. The application service will use the existing `User` and `Post` domain models.

HTTP handling belongs in the API layer. SQLite access belongs in the database or persistence layer. The application service must not implement HTTP handling or execute SQLite queries directly.

## 6. Implementation status

This document defines the planned API contract only. The `POST /posts` endpoint, persistence logic, and CRUD functionality are not implemented as part of this week's task.